from pymongo import MongoClient
from bson.json_util import dumps

class AnimalShelter(object):
    
    def __init__(self, usr='aacuser', pwd='Password55', host='nv-desktop-services.apporto.com', port=30119, db='AAC', collection='animals'):
        # Initialize the MongoClient using provided connection parameters
        self.client = MongoClient(f'mongodb://{usr}:{pwd}@{host}:{port}')
        self.database = self.client[db]
        self.collection = self.database[collection]

    def create(self, data):
        # Insert a document into the specified MongoDB database and collection
        if data is not None:
            self.collection.insert(data)
        else:
            raise Exception("Nothing to save because data parameter is empty")

    def read(self, read_data=None):
        # Query for document(s) from the specified MongoDB database and collection
        if read_data:
            data = self.collection.find(read_data, {"_id": False})
        else:
            data = self.collection.find({}, {"_id": False})
        # Return the result in JSON format
        return dumps(data)

    def update(self, pair_to_find, pair_to_replace):
        try:
            # Query for and update document(s) in the specified MongoDB database and collection
            result = self.collection.update_many(pair_to_find, {"$set": pair_to_replace})
            # Return the number of objects modified in the collection
            return result.modified_count
        except:
            raise Exception("Update failed")

    def delete(self, delete_data):
        try:
            # Query for and remove document(s) from the specified MongoDB database and collection
            result = self.collection.delete_many(delete_data)
            # Return the number of objects removed from the collection
            return result.deleted_count
        except:
            raise Exception("Delete failed")
